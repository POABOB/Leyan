Vue.component('my-modal', {
  template: 
  `
  <div class="Modal-rootOverlay" v-show='show' @click.self='close'>
    <div class="Modal-Card" :class='[mod, position]'>
      <div v-if='title' class="title">{{ title }}</div>
      <div class="body">
        <slot></slot>
      </div>
      <div class="actions">
        <slot name="actions">
          <button class="btn red" @click='close'>close</button>
        </slot>
      </div>
    </div>
  </div>
  `,
  props: {
    show: Boolean,
    mod: String,
    title: String,
    position: {
      type: String,
      default: 'Y_center'
    }
  },
  watch: {
    show(isShow) {
      document.body.style.cssText = (isShow) ? "height:100vh;overflow:hidden;" : "";
    }
  },
  methods: {
    close() {
      this.$emit('update:show', false);
      document.body.style = '';
    },
  }
});